# helper-bot
A command-line bot which can do a lot of things!
